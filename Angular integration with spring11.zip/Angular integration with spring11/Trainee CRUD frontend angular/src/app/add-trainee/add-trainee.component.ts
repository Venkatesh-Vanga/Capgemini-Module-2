import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Trainees } from '../myservice.service';

@Component({
  selector: 'app-add-trainee',
  templateUrl: './add-trainee.component.html',
  styleUrls: ['./add-trainee.component.css']
})
export class AddTraineeComponent implements OnInit {
  message: string;

  constructor(private myservice: MyserviceService,private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(addtra:Trainees):any{
    console.log(addtra);
     this.myservice.addTra(addtra).subscribe(data => {
      this.message=data});
  }

}
