import { Component, OnInit } from '@angular/core';
import { MyserviceService, Trainees } from '../myservice.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list-trainee',
  templateUrl: './list-trainee.component.html',
  styleUrls: ['./list-trainee.component.css']
})
export class ListTraineeComponent implements OnInit {
  message: string;
  trainees: Trainees[];
  constructor(private myservice: MyserviceService, private router: Router) {
  }

  ngOnInit(): any {
    this.myservice.getTrainees().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.trainees = response;
  }
  update(updatetrainee: Trainees) {
    this.myservice.update(updatetrainee);
    this.router.navigate(['/updatetrainee']); //updating the trainee
  }
  delete(deletetrainee: Trainees): any {
    this.myservice.delete(deletetrainee.id).subscribe(data => {
      this.message = data
    });
    this.router.navigate(['/listoftrainee']);
  }
}
